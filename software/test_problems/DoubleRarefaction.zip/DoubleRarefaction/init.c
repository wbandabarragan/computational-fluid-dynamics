/* ///////////////////////////////////////////////////////////////////// */
/*!
  \file
  \brief Double rarefaction problem.

  Two streams of gas moving apart, which open a near-vacuum region
  between them. The initial condition is a discontinuity separating
  two states with the same density and pressure and opposite velocities:
  \f[
     \begin{array}{lcll}
   \left(\rho,\, v_x,\, p\right)_L &=&
    \left(1,  -2,  0.4\right)   & \qquad\mathrm{for}\quad x < 0.5
     \\ \noalign{\medskip}
   \left(\rho,\, v_x,\, p\right)_R &=&
    \left(1,  +2,  0.4\right)
      & \qquad\mathrm{for}\quad x > 0.5
   \end{array}
  \f]
  The solution at \c t=0.15 consists of two rarefaction waves travelling
  outwards, with no shock and no jump in density at the contact. It is the
  standard test for the robustness of a Riemann solver near a vacuum.

  \b References
     - Toro, E. F., "Riemann Solvers and Numerical Methods for Fluid
       Dynamics", 2nd ed., Sect. 4.3.3 (Test 2).
     - Zingale, M., "Introduction to Computational Astrophysical
       Hydrodynamics", Eq. 8.109.

*/
/* ///////////////////////////////////////////////////////////////////// */
#include "pluto.h"

/* ********************************************************************* */
void Init (double *v, double x1, double x2, double x3)
/*
 *
 *********************************************************************** */
{
  #if EOS == IDEAL
   g_gamma = 1.4;
  #endif

  v[RHO] = 1.0;
  v[PRS] = 0.4;

  if (x1 < 0.5) {
    v[VX1] = -2.0;
  }else{
    v[VX1] =  2.0;
  }
  v[VX2] = 0.0;
  v[VX3] = 0.0;

}

/* ********************************************************************* */
void InitDomain (Data *d, Grid *grid)
/*!
 * Assign initial condition by looping over the computational domain.
 *
 *********************************************************************** */
{
}

/* ********************************************************************* */
void Analysis (const Data *d, Grid *grid)
/*
 *
 *********************************************************************** */
{
}
/* ********************************************************************* */
void UserDefBoundary (const Data *d, RBox *box, int side, Grid *grid)
/*
 *
 *********************************************************************** */
{
}
