# DoubleRarefaction: Toro's Test 2 with PLUTO, set up to match nb19

Two streams of gas moving apart, which open a near-vacuum region between them.
The same solver and the same settings as the Sod directory, so the two tests
can be compared directly, and the same three reconstructions in
`other_configs`.

| Item | nb19 (Python) | PLUTO (this setup) |
|---|---|---|
| Left state | (1.0, -2.0, 0.4) | `init.c`, x < 0.5 |
| Right state | (1.0, +2.0, 0.4) | `init.c`, x > 0.5 |
| Adiabatic index | 1.4 | `g_gamma = 1.4` in `init.c` |
| Domain, diaphragm | [0, 1], x0 = 0.5 | `X1-grid 1 0.0 512 u 1.0` |
| CFL | 0.8 | `CFL 0.8` |
| Final time | 0.15 | `tstop 0.15` |
| Boundaries | outflow | `outflow` |
| Riemann solver | CGF two-shock | `Solver two_shock` |

The exact star state is p* = 1.894e-3 and u* = 0, with rho* = 0.0219 on both
sides: a near-vacuum, but not a vacuum, since the velocity jump of 4 is below
the threshold 2(c_l + c_r)/(gamma - 1) = 7.48 of Toro's pressure positivity
condition (Eq. 4.40).

This is the standard test of the robustness of a Riemann solver. Changing
`Solver` in `pluto.ini` is enough to see it: `tvdlf`, `hll`, `hllc` and
`two_shock` finish the run, while `roe` stops with a negative pressure on the
third step.
